# Guidekul Career DNA

A Next.js (App Router, TypeScript, Tailwind) wrapper around the standalone
**Guidekul Career DNA** tool. The tool is a single static HTML file that talks
to a server-side API route, which proxies requests to Google's Gemini model.
The Gemini API key stays on the server and is never exposed to the browser.

## How it works

- `public/tools/career-desert-mvp2.html` is the standalone tool. It calls
  `POST /api/ai` with a JSON body `{ prompt, max_tokens }`.
- `app/api/ai/route.ts` reads `GEMINI_API_KEY` from the server environment,
  calls Gemini's `generateContent` endpoint (with
  `generationConfig.responseMimeType` set to `application/json` so Gemini
  returns clean JSON), and normalizes the reply into the shape the tool
  expects: `{ content: [{ text: "..." }] }`.
- `app/career-dna/page.tsx` embeds the tool in a full-viewport, borderless
  iframe. Visit `/career-dna` to use it.

## Setup

1. Install dependencies:

   ```bash
   npm install
   ```

2. Create your local environment file from the example and add your key:

   ```bash
   cp .env.local.example .env.local
   ```

   Then open `.env.local` and set `GEMINI_API_KEY` to your key.

### Getting a Gemini API key

1. Go to https://aistudio.google.com/apikey
2. Sign in with a Google account.
3. Click **Create API key** and copy the value.
4. Paste it into `.env.local` as `GEMINI_API_KEY=your_key_here`.

The free tier is enough to develop and test. Do not commit `.env.local` or share
the key. Only ever put the key in `.env.local` (local) or in the hosting
provider's environment variables (production).

## Local development

```bash
npm run dev
```

Then open:

- http://localhost:3000 - landing page
- http://localhost:3000/career-dna - the Career DNA tool

The tool's requests to `/api/ai` are handled by the server route, so the key is
never sent to the browser.

## Environment variables

| Variable         | Required | Description                                                        |
| ---------------- | -------- | ------------------------------------------------------------------ |
| `GEMINI_API_KEY` | Yes      | Your Google Gemini API key (server-side only).                     |
| `GEMINI_MODEL`   | No       | Gemini model name. Defaults to `gemini-2.0-flash` if not set.      |

## Deploying to Vercel

1. Push this project to a GitHub repository.

2. In [Vercel](https://vercel.com/new), click **Add New... > Project** and
   import the repository. Vercel auto-detects Next.js, so the default build
   settings work as is.

3. Add the environment variable before (or right after) the first deploy:

   - In the Vercel dashboard, go to your project's
     **Settings > Environment Variables**.
   - Add a variable named `GEMINI_API_KEY` with your key as the value.
   - Select the environments it applies to (**Production**, **Preview**, and
     **Development**). Setting it for all three is fine.
   - Optionally add `GEMINI_MODEL` the same way to override the default model.
   - Click **Save**.

4. Trigger a deploy (Vercel deploys automatically on push, or use **Deployments
   > Redeploy**). If you added the variable after the first deploy, redeploy so
   the running app picks it up.

5. Once deployed, the tool is available at `https://your-project.vercel.app/career-dna`.

You can also set environment variables from the CLI:

```bash
npm i -g vercel
vercel env add GEMINI_API_KEY
```

### Custom domain

In the Vercel dashboard, open **Settings > Domains**, add your domain, and
follow the DNS instructions Vercel shows (either point your domain's
nameservers to Vercel or add the CNAME/A records it lists). The domain goes
live once DNS propagates.

## Project structure

```
guidekul-career-dna/
├─ app/
│  ├─ api/ai/route.ts        # POST route that proxies to Gemini
│  ├─ career-dna/page.tsx    # iframe wrapper for the tool
│  ├─ globals.css
│  ├─ layout.tsx
│  └─ page.tsx               # simple landing page
├─ public/
│  └─ tools/
│     └─ career-desert-mvp2.html   # the standalone tool
├─ .env.local.example
├─ next.config.mjs
├─ package.json
├─ tailwind.config.ts
└─ tsconfig.json
```
